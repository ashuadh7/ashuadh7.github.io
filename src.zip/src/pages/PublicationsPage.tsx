const PublicationsPage = () => {
    return (
        <div>
            <h1>Publications</h1>
            <p>List of my research publications and papers.</p>
        </div>
    );
};

export default PublicationsPage;
