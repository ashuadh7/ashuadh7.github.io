const AboutPage = () => {
    return (
        <div>
            <h1>About Me</h1>
            <p>Information about my background and research.</p>
        </div>
    );
};

export default AboutPage;
