import React from "react";

const VRVsChronicPain = () => {
    return (
        <div>
            <h2>VR vs Chronic Pain</h2>
            <p>Could a headset be a game-changer in managing long-term pain?</p>
        </div>
    );
};

export default VRVsChronicPain;
