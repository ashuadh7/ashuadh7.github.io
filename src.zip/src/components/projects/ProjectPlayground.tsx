import React from "react";

const ProjectPlayground = () => {
    return (
        <div>
            <h2>Project Playground</h2>
            <p>Assortment of projects. Dipping my toes in everything!</p>
        </div>
    );
};

export default ProjectPlayground;
