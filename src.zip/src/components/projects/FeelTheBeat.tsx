import React from "react";

const FeelTheBeat = () => {
    return (
        <div>
            <h2>Feel the Beat in VR</h2>
            <p>Dive into the fusion of digital and physical music creation.</p>
        </div>
    );
};

export default FeelTheBeat;
