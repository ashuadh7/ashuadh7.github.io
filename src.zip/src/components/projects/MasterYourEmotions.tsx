import React from "react";

const MasterYourEmotions = () => {
    return (
        <div>
            <h2>Master Your Emotions in VR</h2>
            <p>
                Explore how VR can teach us to control and understand our emotions
                in a safe, immersive space.
            </p>
        </div>
    );
};

export default MasterYourEmotions;
