import React from "react";

const VRBeyondTheOrdinary = () => {
    return (
        <div>
            <h2>VR Beyond the Ordinary</h2>
            <p>Can virtual reality spark mind-blowing, perspective-shifting experiences?</p>
        </div>
    );
};

export default VRBeyondTheOrdinary;
